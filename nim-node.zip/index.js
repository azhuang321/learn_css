const { Sequelize,QueryTypes } = require('sequelize');

const sequelize = new Sequelize('azhuangtest', 'azhuangtest', '123123123', {
    host: 'sql.wsfdb.cn',
    dialect: 'mysql',
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000
    }
});

(async () => {
    const users = await sequelize.query("create database test ", { type: QueryTypes.SELECT });
    console.log(users)
})()
